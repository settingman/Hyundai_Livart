package dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PreOrdersVO {
	private String orderer;
	private String orderer_phone;
}

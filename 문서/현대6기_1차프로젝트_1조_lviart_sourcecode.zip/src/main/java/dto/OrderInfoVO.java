package dto;

public class OrderInfoVO {

}

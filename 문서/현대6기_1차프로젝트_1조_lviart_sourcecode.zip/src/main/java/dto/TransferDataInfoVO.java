package dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TransferDataInfoVO {
	
	private String p_id;
	private int p_price;
	private int quantity;
}
